package algo42Full.modelo;

public interface Atacable {
	
	public void recibirDanio(int cantDanio);

}
