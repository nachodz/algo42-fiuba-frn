package algo42Full.modelo.excepciones;

public class NoTieneTorpedosException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
