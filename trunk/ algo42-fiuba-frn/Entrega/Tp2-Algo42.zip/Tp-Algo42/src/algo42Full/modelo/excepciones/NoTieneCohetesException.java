package algo42Full.modelo.excepciones;

public class NoTieneCohetesException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
