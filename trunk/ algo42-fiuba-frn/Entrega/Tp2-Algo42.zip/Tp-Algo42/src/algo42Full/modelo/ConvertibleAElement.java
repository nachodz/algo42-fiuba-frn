package algo42Full.modelo;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public interface ConvertibleAElement {
	
	public Element getElement(Document doc);

}
