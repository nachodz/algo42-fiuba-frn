package algo42Full.vista;


public class VistaCaza extends VistaNave{
	
	public VistaCaza(){
		this.setNombreArchivoImagen("/media/caza.png");
	}

}
