package algo42Full.vista;

import ar.uba.fi.algo3.titiritero.vista.Imagen;

public class VistaPantallaNivelTerminado extends Imagen{
	
	public VistaPantallaNivelTerminado(){
		this.setNombreArchivoImagen("/media/fondoNivelTerminado.jpg");
	}

}
