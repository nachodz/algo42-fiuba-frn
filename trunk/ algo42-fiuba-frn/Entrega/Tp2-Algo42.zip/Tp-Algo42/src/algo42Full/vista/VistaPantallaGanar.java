package algo42Full.vista;

import ar.uba.fi.algo3.titiritero.vista.Imagen;

public class VistaPantallaGanar extends Imagen{
	
	public VistaPantallaGanar(){
		this.setNombreArchivoImagen("/media/fondoGanar.jpg");
	}

}
