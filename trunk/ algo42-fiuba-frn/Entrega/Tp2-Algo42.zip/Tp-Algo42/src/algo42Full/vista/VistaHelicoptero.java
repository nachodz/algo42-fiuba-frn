package algo42Full.vista;


public class VistaHelicoptero extends VistaNave{
	
	public VistaHelicoptero(){
		this.setNombreArchivoImagen("/media/helicoptero.png");
	}

}
