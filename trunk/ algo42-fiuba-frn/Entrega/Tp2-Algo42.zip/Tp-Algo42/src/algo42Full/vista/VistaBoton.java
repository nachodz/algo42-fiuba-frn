package algo42Full.vista;

import ar.uba.fi.algo3.titiritero.vista.Imagen;

public class VistaBoton extends Imagen{

	public VistaBoton(String nombreArchivoImagen){
		this.setNombreArchivoImagen(nombreArchivoImagen);
	}
	
}
