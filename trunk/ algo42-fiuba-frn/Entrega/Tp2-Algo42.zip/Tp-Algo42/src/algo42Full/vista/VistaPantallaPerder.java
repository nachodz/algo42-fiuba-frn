package algo42Full.vista;

import ar.uba.fi.algo3.titiritero.vista.Imagen;

public class VistaPantallaPerder extends Imagen {
	
	public VistaPantallaPerder(){
		this.setNombreArchivoImagen("/media/fondoPerder.jpg");
	}

}
