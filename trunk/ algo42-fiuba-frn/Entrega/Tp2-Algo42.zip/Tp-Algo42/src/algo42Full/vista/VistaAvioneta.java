package algo42Full.vista;



public class VistaAvioneta extends VistaNave{
	
	public VistaAvioneta(){
		this.setNombreArchivoImagen("/media/avioneta.png");
	}

}

