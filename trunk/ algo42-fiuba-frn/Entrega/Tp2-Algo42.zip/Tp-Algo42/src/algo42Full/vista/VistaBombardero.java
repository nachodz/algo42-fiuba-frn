package algo42Full.vista;


public class VistaBombardero extends VistaNave{
	
	public VistaBombardero(){
		this.setNombreArchivoImagen("/media/bombardero.png");
	}

}
