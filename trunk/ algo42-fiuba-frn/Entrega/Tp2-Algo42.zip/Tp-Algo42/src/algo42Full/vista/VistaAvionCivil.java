package algo42Full.vista;


public class VistaAvionCivil extends VistaNave{
	
	public VistaAvionCivil(){
		this.setNombreArchivoImagen("/media/civil.png");
	}

}
