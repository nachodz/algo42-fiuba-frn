package algo42Full.vista;

import ar.uba.fi.algo3.titiritero.vista.Imagen;

public class VistaCazaII extends Imagen{
	
	public VistaCazaII(){
		this.setNombreArchivoImagen("/media/cazaII.png");
	}

}
