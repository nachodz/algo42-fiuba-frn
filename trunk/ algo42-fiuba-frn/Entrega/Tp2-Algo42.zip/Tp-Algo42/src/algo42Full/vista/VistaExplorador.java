package algo42Full.vista;


public class VistaExplorador extends VistaNave{
	
	public VistaExplorador(){
		this.setNombreArchivoImagen("/media/explorador.png");
	}

}
