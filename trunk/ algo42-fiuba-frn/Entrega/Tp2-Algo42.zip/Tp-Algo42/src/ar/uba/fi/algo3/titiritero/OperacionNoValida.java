package ar.uba.fi.algo3.titiritero;

public class OperacionNoValida extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
