package ar.uba.fi.algo3.titiritero;

import java.awt.event.KeyEvent;

public interface KeyPressedObservador {
	public void keyPressed(KeyEvent event);
	public void keyReleased(KeyEvent event);
}
