package ar.uba.fi.algo3.titiritero;

public interface MouseClickObservador {
	
	public void MouseClick(int x, int y);
	
}
