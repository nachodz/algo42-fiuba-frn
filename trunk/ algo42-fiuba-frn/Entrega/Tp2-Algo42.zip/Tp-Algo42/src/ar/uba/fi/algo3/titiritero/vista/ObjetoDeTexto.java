package ar.uba.fi.algo3.titiritero.vista;

public interface ObjetoDeTexto {
	public String getTexto();
}
