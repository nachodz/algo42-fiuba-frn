package ar.uba.fi.algo3.titiritero;

public interface Accion {

	public void ejecutarAccion();
}
